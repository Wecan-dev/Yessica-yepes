<div class="edge-register-notice">
	<h5><?php echo esc_html($message); ?></h5>
	<a href="#" class="edge-login-action-btn" data-el="#edge-login-content" data-title="<?php esc_attr_e('LOGIN', 'edge-membership'); ?>"><?php esc_html_e('LOGIN', 'edge-membership'); ?></a>
</div>