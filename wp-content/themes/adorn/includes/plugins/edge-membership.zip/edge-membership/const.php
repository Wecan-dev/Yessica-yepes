<?php

define('EDGE_MEMBERSHIP_VERSION', '1.0.1');
define('EDGE_MEMBERSHIP_ABS_PATH', dirname(__FILE__));
define('EDGE_MEMBERSHIP_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('EDGE_MEMBERSHIP_SHORTCODES_PATH', EDGE_MEMBERSHIP_ABS_PATH.'/shortcodes');