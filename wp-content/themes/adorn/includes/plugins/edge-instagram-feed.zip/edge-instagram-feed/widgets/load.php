<?php

include_once 'edge-instagram-widget.php';