<?php

include_once 'lib/edge-instagram-api.php';
include_once 'widgets/load.php';