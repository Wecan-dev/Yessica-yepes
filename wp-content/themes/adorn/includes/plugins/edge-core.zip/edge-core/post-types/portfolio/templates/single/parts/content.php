<div class="edge-ps-info-item edge-ps-content-item">
    <h2 class="edge-portfolio-item-title"><?php the_title(); ?></h2>
    <?php the_content(); ?>
</div>