<?php

include_once EDGE_CORE_CPT_PATH.'/team/team-register.php';
include_once EDGE_CORE_CPT_PATH.'/team/helper-functions.php';
include_once EDGE_CORE_CPT_PATH.'/team/shortcodes/shortcodes-functions.php';