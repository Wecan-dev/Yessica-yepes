<?php

get_header();

adorn_edge_get_title();

edge_core_get_single_team();

get_footer();