<?php

get_header();

adorn_edge_get_title(false, 'portfolio_single');

edge_core_get_single_portfolio();

get_footer();