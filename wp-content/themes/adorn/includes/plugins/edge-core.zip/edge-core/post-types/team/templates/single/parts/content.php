<div class="edge-team-single-content">
	<?php the_content(); ?>
</div>