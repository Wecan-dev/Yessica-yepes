<?php

include_once EDGE_CORE_SHORTCODES_PATH.'/frame-video/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/frame-video/frame-video.php';