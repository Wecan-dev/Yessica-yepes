<div class="edge-split-scrolling-section">
    <?php echo do_shortcode($content); ?>
</div>