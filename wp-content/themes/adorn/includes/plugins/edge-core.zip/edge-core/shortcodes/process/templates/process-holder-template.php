<div <?php adorn_edge_class_attribute($holder_classes); ?>>
	<div class="edge-process-bg-holder"></div>
	<div class="edge-process-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>