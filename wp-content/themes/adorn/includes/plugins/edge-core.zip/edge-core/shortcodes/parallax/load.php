<?php

include_once EDGE_CORE_SHORTCODES_PATH.'/parallax/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/parallax/parallax.php';

