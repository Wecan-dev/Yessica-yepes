<div class="edge-parallax-holder <?php echo esc_attr($holder_class); ?>" <?php echo adorn_edge_get_inline_attrs($holder_data); ?> <?php echo adorn_edge_get_inline_style($holder_style); ?>>
	<div class="edge-parallax-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>
