<div class="edge-clients-boxes-holder <?php echo esc_attr($holder_classes); ?>">
	<div class="edge-cb-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>