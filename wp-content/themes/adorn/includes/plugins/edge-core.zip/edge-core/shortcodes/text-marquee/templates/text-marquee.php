<div class="edge-text-marquee">
    <div class="edge-text-marquee-wrapper">
        <span class="edge-text-marquee-title" style="<?php echo esc_attr($title_style); ?>"><?php echo esc_attr($title); ?></span>
        <span class="edge-text-marquee-title edge-aux-text" style="<?php echo esc_attr($title_style); ?>"><?php echo esc_attr($title); ?></span>
    </div>
</div>