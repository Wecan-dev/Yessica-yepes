(function($) {
	'use strict';
	
	$(document).ready(function(){
		edgeInitSplitScrollingSection();
	});
	
	/*
	 **	Split Scrolling Section
	 */
	function edgeInitSplitScrollingSection() {}
	
})(jQuery);