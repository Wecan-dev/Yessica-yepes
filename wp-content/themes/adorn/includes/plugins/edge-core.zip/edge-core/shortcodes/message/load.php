<?php

include_once EDGE_CORE_SHORTCODES_PATH.'/message/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/message/message.php';