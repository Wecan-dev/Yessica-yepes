<?php

include_once EDGE_CORE_SHORTCODES_PATH.'/item-showcase/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/item-showcase/item-showcase.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/item-showcase/item-showcase-item.php';
