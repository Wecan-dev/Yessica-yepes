<div class="edge-sss-ms-section" <?php echo adorn_edge_get_inline_attrs($content_data); ?> <?php adorn_edge_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>