<div class="edge-mobile-slider-holder">
    <div class="edge-ms-inner edge-owl-slider" <?php echo adorn_edge_get_inline_attrs($slider_data); ?>>
        <?php echo do_shortcode($content); ?>
    </div>
</div>