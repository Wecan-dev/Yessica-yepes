<div class="edge-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>">
	<div class="edge-separator" <?php echo adorn_edge_get_inline_style($separator_style); ?>></div>
</div>
